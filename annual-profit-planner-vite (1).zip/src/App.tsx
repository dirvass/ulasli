
import React, { useMemo, useState } from "react";

type Villa = {
  id: string;
  name: string;
  dailyFee: number;
  occupancy: number;
  costPct: number;
};

export default function App() {
  const [villas, setVillas] = useState<Villa[]>([
    { id: crypto.randomUUID(), name: "Villa A", dailyFee: 750, occupancy: 0.6, costPct: 0.35 },
    { id: crypto.randomUUID(), name: "Villa B", dailyFee: 500, occupancy: 0.6, costPct: 0.35 },
  ]);

  const [currency, setCurrency] = useState("€");

  const fmt = (n: number) => new Intl.NumberFormat("de-DE", { maximumFractionDigits: 2 }).format(n);

  const rows = useMemo(() => {
    return villas.map(v => {
      const ebitda = v.dailyFee * 365 * v.occupancy;
      const net = ebitda * (1 - v.costPct);
      return { ...v, ebitda, net };
    });
  }, [villas]);

  const totals = useMemo(() => {
    const ebitda = rows.reduce((a, r) => a + r.ebitda, 0);
    const net = rows.reduce((a, r) => a + r.net, 0);
    return { ebitda, net };
  }, [rows]);

  function update(id: string, patch: Partial<Villa>) {
    setVillas(prev => prev.map(v => (v.id === id ? { ...v, ...patch } : v)));
  }

  function addVilla() {
    const idx = villas.length + 1;
    setVillas(prev => [
      ...prev,
      { id: crypto.randomUUID(), name: `Villa ${String.fromCharCode(64 + idx)}`, dailyFee: 600, occupancy: 0.6, costPct: 0.35 },
    ]);
  }

  function removeVilla(id: string) {
    setVillas(prev => prev.filter(v => v.id !== id));
  }

  function preset(type: "pessimistic" | "base" | "optimistic") {
    setVillas(prev =>
      prev.map(v => {
        if (type === "pessimistic") return { ...v, dailyFee: Math.round(v.dailyFee * 0.67), occupancy: 0.6, costPct: 0.4 };
        if (type === "optimistic") return { ...v, dailyFee: Math.round(v.dailyFee * 1.33), occupancy: 0.6, costPct: 0.3 };
        return { ...v, occupancy: 0.6, costPct: 0.35 };
      })
    );
  }

  return (
    <div style={{fontFamily: "Inter, system-ui, Arial, sans-serif", padding: 16}}>
      <h1 style={{fontSize: 20, fontWeight: 700, marginBottom: 8}}>Annual Profit Planner</h1>

      <div style={{display: "flex", gap: 8, marginBottom: 12}}>
        <button onClick={() => preset("pessimistic")}>Pesimistik</button>
        <button onClick={() => preset("base")}>Muhtemel</button>
        <button onClick={() => preset("optimistic")}>Optimistik</button>
        <div style={{marginLeft: "auto"}}>
          <label style={{marginRight: 6}}>Currency</label>
          <select value={currency} onChange={e => setCurrency(e.target.value)}>
            <option value="€">€ Euro</option>
            <option value="$">$ USD</option>
            <option value="£">£ GBP</option>
          </select>
        </div>
      </div>

      <div style={{overflowX: "auto"}}>
        <table style={{width: "100%", borderCollapse: "collapse"}}>
          <thead>
            <tr style={{background: "#f5f5f5"}}>
              <th style={{textAlign:"left", padding: 8}}>Villa</th>
              <th style={{textAlign:"left", padding: 8}}>Daily Fee</th>
              <th style={{textAlign:"left", padding: 8}}>Occupancy %</th>
              <th style={{textAlign:"left", padding: 8}}>Cost %</th>
              <th style={{textAlign:"left", padding: 8}}>EBITDA (annual)</th>
              <th style={{textAlign:"left", padding: 8}}>Net Profit (annual)</th>
              <th style={{textAlign:"left", padding: 8}}>5Y ROI</th>
              <th style={{textAlign:"left", padding: 8}}>10Y ROI</th>
              <th style={{textAlign:"left", padding: 8}}>15Y ROI</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} style={{borderTop: "1px solid #eee"}}>
                <td style={{padding: 8}}>
                  <input value={r.name} onChange={e => update(r.id, { name: e.target.value })} style={{width: 110}}/>
                </td>
                <td style={{padding: 8}}>
                  <span>{currency} </span>
                  <input type="number" min={0} value={r.dailyFee} onChange={e => update(r.id, { dailyFee: Number(e.target.value || 0) })} style={{width: 100}}/>
                </td>
                <td style={{padding: 8}}>
                  <input type="number" min={0} max={100} value={Math.round(r.occupancy*100)} onChange={e => update(r.id, { occupancy: Math.min(100, Math.max(0, Number(e.target.value))) / 100 })} style={{width: 80}}/>%
                </td>
                <td style={{padding: 8}}>
                  <input type="number" min={0} max={100} value={Math.round(r.costPct*100)} onChange={e => update(r.id, { costPct: Math.min(100, Math.max(0, Number(e.target.value))) / 100 })} style={{width: 80}}/>%
                </td>
                <td style={{padding: 8}}>{currency} {fmt(r.ebitda)}</td>
                <td style={{padding: 8}}>{currency} {fmt(r.net)}</td>
                <td style={{padding: 8}}>{currency} {fmt(r.net*5)}</td>
                <td style={{padding: 8}}>{currency} {fmt(r.net*10)}</td>
                <td style={{padding: 8}}>{currency} {fmt(r.net*15)}</td>
                <td style={{padding: 8}}><button onClick={() => removeVilla(r.id)}>Sil</button></td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr style={{borderTop: "2px solid #ddd", fontWeight: 700}}>
              <td style={{padding: 8}}>Toplam</td>
              <td></td><td></td><td></td>
              <td style={{padding: 8}}>{currency} {fmt(totals.ebitda)}</td>
              <td style={{padding: 8}}>{currency} {fmt(totals.net)}</td>
              <td style={{padding: 8}}>{currency} {fmt(totals.net*5)}</td>
              <td style={{padding: 8}}>{currency} {fmt(totals.net*10)}</td>
              <td style={{padding: 8}}>{currency} {fmt(totals.net*15)}</td>
              <td></td>
            </tr>
          </tfoot>
        </table>
      </div>

      <p style={{fontSize: 12, color: "#666", marginTop: 8}}>
        Formulas: EBITDA = Daily Fee × 365 × Occupancy. Net Profit = EBITDA × (1 - Cost%). ROI = Net Profit × years.
      </p>
    </div>
  );
}
